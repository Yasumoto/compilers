#!/bin/sh

make clean && make && cd cls && java Triangle.Compiler ../joe.tri

java TAM.Interpreter obj.tam
